/*Verificare che i campi definiti come PK siano univoci.*/

SELECT
COUNT(CategoryId) PK
,COUNT(*) conteggio
FROM 
category;

SELECT 
COUNT(ProductId) PK
,COUNT(*) conteggio
FROM                                                  
product;

SELECT 
COUNT(RegionId) PK
,COUNT(*) conteggio
FROM
region;

SELECT
COUNT(CONCAT(SalesOrderNumber , '-' , SalesOrderLineNumber)) PK
,COUNT(*) conteggio
FROM
sales;        /*Nelle query sopra ho verificato l'univocità delle chiavi primarie di ogni tabella confrontando il conteggio della PK 
				con il conteggio di tutti i record della tabella se le due cose corrispondono allora significa che sono univoche*/
                

/*Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.*/

SELECT
p.NomeProdotto 
,SUM(v.SalesAmount) FatturatoTOT
,YEAR(s.OrderDate) Anno
FROM 
vw_salesamount AS v INNER JOIN
sales AS s ON v.ProductId = s.ProductId						
INNER JOIN                                                  
product AS p ON p.ProductId = s.ProductId
GROUP BY
p.NomeProdotto
,YEAR(s.OrderDate);    		/*Usando una inner join prendo solo i campi della tabella product per la quale ho una
                             corrispondenza nella tabella sales e quindi quelli che sono stati venduti*/ 

/*Esporre il fatturato totale per stato per anno.Ordina il risultato per data e per fatturato decrescente.*/

SELECT
SUM(v.SalesAmount) FatturatTOT
,YEAR(s.OrderDate) Anno
,r.NomeRegione Stato
FROM 
vw_salesamount AS v INNER JOIN 
sales AS s ON v.ProductId = s.ProductId
INNER JOIN region AS r
ON s.RegionId = r.RegionId
GROUP BY 
YEAR(s.OrderDate)
,r.NomeRegione
ORDER BY 
SUM(v.SalesAmount) DESC;

/*Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT
c.Nome Categoria
,COUNT(s.ProductId) conteggio
FROM 
sales AS s INNER JOIN 
product AS p ON s.ProductId = p.ProductId
INNER JOIN category AS c 
ON c.CategoryId = p.CategoryId
GROUP BY 
c.Nome
ORDER BY
COUNT(s.ProductId) DESC
LIMIT 1;

/*Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.*/

SELECT
p.ProductId
,p.NomeProdotto
,s.SalesOrdernumber
,s.SalesOrderlinenumber
FROM 
product AS p LEFT JOIN
sales AS s ON p.ProductId = s.ProductId
WHERE
s.ProductId IS NULL;     /*1 approccio : facendo una left join da prodotti verso sales gli chiedo se nella tabella prodotti c'è qualche 
										qualche productId null nel caso mi ritorni qualche record allora quei record sono prodotti non venduti*/

SELECT p.ProductId, p.NomeProdotto
FROM product p
WHERE NOT EXISTS (
    SELECT *
    FROM sales s
    WHERE s.ProductId = p.ProductId
);                                         /*2 approccio: qui con una subquery verifico se per un prodotto esiste una riga corrispondente 
														  nella tabella sales. Possiamo notare infatti come il risultato sia lo stesso della query sopra*/

/*Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).*/

SELECT
p.NomeProdotto
,MAX(s.OrderDate) ultimaVendita
FROM 
product AS p INNER JOIN
sales AS s ON p.ProductId = s.ProductId
GROUP BY
p.NomeProdotto
ORDER BY
MAX(s.OrderDate) DESC;            		/*Per ricavarmi l'ultima data di vendita in relazione al prodotto ho usato la funzione max */
