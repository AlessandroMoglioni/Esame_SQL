CREATE DATABASE toysgroup;

USE toysgroup;

CREATE TABLE category (
CategoryId INT NOT NULL AUTO_INCREMENT PRIMARY KEY
,Nome VARCHAR (50));

CREATE TABLE product (
ProductId INT NOT NULL AUTO_INCREMENT PRIMARY KEY
,NomeProdotto VARCHAR (50)
,ListPrice DECIMAL (10 , 2)
,CategoryId INT
,FOREIGN KEY(CategoryId) REFERENCES category(CategoryId));

CREATE TABLE region (
RegionId INT NOT NULL AUTO_INCREMENT PRIMARY KEY
,Città VARCHAR (50)
,NomeRegione VARCHAR (50));

CREATE TABLE sales (
SalesOrdernumber INT AUTO_INCREMENT 
,SalesOrderlinenumber INT 
,Quantità INT 
,OrderDate DATE 
,RegionId INT
,ProductId INT
,PRIMARY KEY (SalesOrdernumber , SalesOrderlinenumber)
,FOREIGN KEY (RegionId) REFERENCES region(RegionId)
,FOREIGN KEY (ProductId) REFERENCES product (ProductId));

INSERT INTO category (nome) 
VALUES 
    ('Macchinine'), 
    ('Bambole'), 
    ('Costruzioni'), 
    ('Peluche'), 
    ('Giochi Educativi');
    
    INSERT INTO product (NomeProdotto, ListPrice , CategoryId)
VALUES
    ('Macchinina sportiva', 15.99, 1),
    ('Bambola fashion', 25.50, 2),
    ('Blocchi di costruzione', 19.99, 3),
    ('Peluche orsacchiotto', 12.99, 4),
    ('Puzzle 3D', 9.99, 5),
    ('Set di auto giocattolo', 18.50, 1),
    ('Bambola interattiva', 40.00, 2),
    ('Set di costruzioni in legno', 22.50, 3),
    ('Peluche gattino', 13.99, 4),
    ('Giochi educativi elettronici', 29.99, 5),
    ('Treno giocattolo', 25.00, 1),
    ('Bambola bambina', 20.00, 2),
    ('Set di blocchi magnetici', 30.00, 3),
    ('Peluche con luci', 17.99, 4),
    ('Giochi da tavolo', 14.99, 5),
    ('Auto radiocomandata', 35.00, 1),
    ('Bambola principessa', 45.00, 2),
    ('Kit di costruzione', 28.00, 3),
    ('Peluche gigante', 60.00, 4),
    ('Giochi creativi', 33.00, 5),
    ('Macchinine da corsa', 22.00, 1),
    ('Bambola parlante', 40.99, 2),
    ('Set di costruzione Lego', 55.00, 3),
    ('Peluche invernale', 25.50, 4),
    ('Puzzle educativi', 18.00, 5),
    ('Giochi in legno', 15.50, 1),
    ('Bambola con accessori', 28.99, 2),
    ('Set di costruzione magnetica', 37.50, 3),
    ('Peluche animali', 19.00, 4),
    ('Giochi educativi bambini', 32.00, 5),
    ('Trenino elettrico', 20.99, 1),
    ('Bambola interattiva', 48.00, 2),
    ('Macchinina in metallo', 16.50, 3),
    ('Peluche pinguino', 14.99, 4),
    ('Gioco da tavolo', 22.50, 5),
    ('Set di macchinine', 27.00, 1),
    ('Bambola vintage', 32.00, 2),
    ('Set di costruzioni 3D', 25.00, 3),
    ('Peluche con suoni', 21.99, 4),
    ('Giochi di società', 19.00, 5),
    ('Macchinina robot', 24.00, 1),
    ('Bambola in peluche', 29.99, 2),
    ('Gioco di carte', 16.00, 5),
    ('Set di costruzione a tema', 38.00, 3),
    ('Peluche colorato', 18.00, 4),
    ('Giocattolo per bambini', 20.50, 1),
    ('Bambola deluxe', 36.00, 2),
    ('Set di blocchi per bambini', 28.00, 3),
    ('Peluche squishy', 14.00, 4),
    ('Giochi da tavolo per adulti', 35.00, 5),
    ('Treno ferroviario', 29.99, 1),
    ('Bambola gigante', 49.99, 2),
    ('Giochi da giardino', 22.00, 5),
    ('Macchinine elettriche', 33.00, 1),
    ('Bambola principessa', 40.00, 2),
    ('Blocchi di costruzione gigante', 55.00, 3),
    ('Peluche morbido', 12.00, 4),
    ('Giocattoli da collezione', 45.00, 5),
    ('Macchinina con luci', 19.99, 1),
    ('Bambola con vestiti', 30.00, 2),
    ('Gioco educativo in legno', 25.99, 5),
    ('Set di costruzioni LEGO', 50.00, 3),
    ('Peluche con cuori', 20.99, 4),
    ('Giochi per bimbi piccoli', 17.00, 5),
    ('Auto da corsa', 22.00, 1),
    ('Bambola con occhiali', 28.50, 2),
    ('Set di Lego Ninjago', 38.50, 3),
    ('Peluche panda', 14.99, 4),
    ('Gioco di squadra', 20.00, 5),
    ('Macchinina volante', 27.00, 1),
    ('Bambola bimba piccola', 30.99, 2),
    ('Costruzioni per bambini', 31.50, 3),
    ('Peluche con cappello', 19.99, 4),
    ('Giocattolo musicale', 23.00, 5),
    ('Giochi di costruzione', 18.50, 3),
    ('Bambola con scarpe', 29.99, 2),
    ('Set di costruzioni in ferro', 40.00, 3),
    ('Peluche foca', 18.00, 4),
    ('Giochi per ragazze', 25.00, 5),
    ('Auto turbo', 30.99, 1),
    ('Bambola con ciocche colorate', 35.50, 2),
    ('Set di costruzione in plastica', 29.99, 3),
    ('Peluche uccellino', 15.50, 4),
    ('Giochi interattivi', 22.00, 5),
    ('Set auto da corsa', 34.00, 1),
    ('Bambola interattiva baby', 32.00, 2),
    ('Costruzioni per adulti', 45.00, 3),
    ('Peluche scimmia', 19.50, 4),
    ('Gioco di ruolo', 30.00, 5),
    ('Treno elettrico Lego', 55.00, 1),
    ('Bambola con pettine', 33.50, 2),
    ('Set di costruzione in cartone', 23.99, 3),
    ('Peluche con pallone', 15.00, 4),
    ('Giochi sportivi', 25.00, 5),
    ('Treno in miniatura', 20.00, 1),
    ('Bambola con capelli lunghi', 25.99, 2),
    ('Set Lego Creator', 45.00, 3),
    ('Peluche con paillettes', 17.00, 4),
    ('Giochi intellettuali', 32.00, 5),
    ('Auto da rally', 26.50, 1),
    ('Bambola ballerina', 29.00, 2),
    ('Set di costruzione 2 in 1', 24.00, 3),
    ('Peluche animaletti', 14.50, 4),
    ('Giochi di costruzione Lego', 38.99, 3);
    
    INSERT INTO region (Città , NomeRegione)
VALUES
    ('Roma', 'Italia'),
    ('Parigi', 'Francia'),
    ('Londra', 'Regno Unito'),
    ('Berlino', 'Germania'),
    ('Madrid', 'Spagna'),
    ('Amsterdam', 'Paesi Bassi'),
    ('Lisboa', 'Portogallo'),
    ('Atene', 'Grecia'),
    ('Vienna', 'Austria'),
    ('Bruxelles', 'Belgio'),
    ('Oslo', 'Norvegia'),
    ('Stoccolma', 'Svezia'),
    ('Praga', 'Repubblica Ceca'),
    ('Budapest', 'Ungheria'),
    ('Zurigo', 'Svizzera'),
    ('Dublino', 'Irlanda'),
    ('Copenhagen', 'Danimarca'),
    ('Helsinki', 'Finlandia'),
    ('Edimburgo', 'Regno Unito'),
    ('Madrid', 'Spagna');
    
    INSERT INTO sales (SalesOrderlinenumber, Quantità, OrderDate , RegionId, ProductId)
VALUES
    (1, 10, '2024-11-01', 1, 1),
    (2, 20, '2024-11-01', 2, 2),
    (3, 15, '2024-11-02', 3, 3),
    (4, 30, '2024-11-02', 4, 4),
    (5, 5, '2024-11-03', 5, 5),
    (6, 25, '2024-11-03', 6, 6),
    (7, 18, '2024-11-04', 7, 7),
    (8, 12, '2024-11-04', 8, 8),
    (9, 14, '2024-11-05', 9, 9),
    (10, 22, '2024-11-05', 10, 10),
    (1, 8, '2024-11-06', 11, 11),
    (2, 16, '2024-11-06', 12, 12),
    (3, 9, '2024-11-07', 13, 13),
    (4, 21, '2024-11-07', 14, 14),
    (5, 18, '2024-11-08', 15, 15),
    (6, 30, '2024-11-08', 16, 16),
    (7, 17, '2024-11-09', 17, 17),
    (8, 19, '2024-11-09', 18, 18),
    (9, 20, '2024-11-10', 19, 19),
    (10, 11, '2024-11-10', 20, 20),
    (1, 5, '2024-11-11', 1, 21),
    (2, 10, '2024-11-11', 2, 22),
    (3, 15, '2024-11-12', 3, 23),
    (4, 30, '2024-11-12', 4, 24),
    (5, 9, '2024-11-13', 5, 25),
    (6, 18, '2024-11-13', 6, 26),
    (7, 20, '2024-11-14', 7, 27),
    (8, 12, '2024-11-14', 8, 28),
    (9, 22, '2024-11-15', 9, 29),
    (10, 11, '2024-11-15', 10, 30),
    (1, 25, '2024-11-16', 11, 31),
    (2, 14, '2024-11-16', 12, 32),
    (3, 17, '2024-11-17', 13, 33),
    (4, 21, '2024-11-17', 14, 34),
    (5, 18, '2024-11-18', 15, 35),
    (6, 27, '2024-11-18', 16, 36),
    (7, 16, '2024-11-19', 17, 37),
    (8, 12, '2024-11-19', 18, 38),
    (9, 10, '2024-11-20', 19, 39),
    (10, 22, '2024-11-20', 20, 40),
    (1, 20, '2024-11-21', 1, 41),
    (2, 30, '2024-11-21', 2, 42),
    (3, 14, '2024-11-22', 3, 43),
    (4, 18, '2024-11-22', 4, 44),
    (5, 15, '2024-11-23', 5, 45),
    (6, 20, '2024-11-23', 6, 46),
    (7, 13, '2024-11-24', 7, 47),
    (8, 17, '2024-11-24', 8, 48),
    (9, 16, '2024-11-25', 9, 49),
    (10, 12, '2024-11-25', 10, 50),
    (1, 5, '2024-11-26', 11, 51),
    (2, 19, '2024-11-26', 12, 52),
    (3, 22, '2024-11-27', 13, 53),
    (4, 14, '2024-11-27', 14, 54),
    (5, 10, '2024-11-28', 15, 55),
    (6, 21, '2024-11-28', 16, 56),
    (7, 18, '2024-11-29', 17, 57),
    (8, 25, '2024-11-29', 18, 58),
    (9, 11, '2024-11-30', 19, 59),
    (10, 23, '2024-11-30', 20, 60),
    (1, 10, '2024-12-01', 1, 61),
    (2, 15, '2024-12-01', 2, 62),
    (3, 18, '2024-12-02', 3, 63),
    (4, 12, '2024-12-02', 4, 64),
    (5, 25, '2024-12-03', 5, 65),
    (6, 14, '2024-12-03', 6, 66),
    (7, 30, '2024-12-04', 7, 67),
    (8, 17, '2024-12-04', 8, 68),
    (9, 22, '2024-12-05', 9, 69),
    (10, 20, '2024-12-05', 10, 70),
    (1, 8, '2024-12-06', 11, 71),
    (2, 13, '2024-12-06', 12, 72),
    (3, 30, '2024-12-07', 13, 73),
    (4, 19, '2024-12-07', 14, 74),
    (5, 22, '2024-12-08', 15, 75),
    (6, 25, '2024-12-08', 16, 76),
    (7, 15, '2024-12-09', 17, 77),
    (8, 13, '2024-12-09', 18, 78),
    (9, 10, '2024-12-10', 19, 79),
    (10, 12, '2024-12-10', 20, 80),
    (1, 14, '2024-12-11', 1, 81),
    (2, 22, '2024-12-11', 2, 82),
    (3, 17, '2024-12-12', 3, 83),
    (4, 18, '2024-12-12', 4, 84),
    (5, 12, '2024-12-13', 5, 85),
    (6, 11, '2024-12-13', 6, 86),
    (7, 19, '2024-12-14', 7, 87),
    (8, 16, '2024-12-14', 8, 88),
    (9, 25, '2024-12-15', 9, 89),
    (10, 30, '2024-12-15', 10, 90),
    (1, 23, '2024-12-16', 11, 91),
    (2, 17, '2024-12-16', 12, 92),
    (3, 18, '2024-12-17', 13, 93),
    (4, 30, '2024-12-17', 14, 94),
    (5, 25, '2024-12-18', 15, 95),
    (6, 22, '2024-12-18', 16, 96),
    (7, 14, '2024-12-19', 17, 97),
    (8, 13, '2024-12-19', 18, 98),
    (9, 16, '2024-12-20', 19, 99),
    (10, 12, '2024-12-20', 20, 100);
    
    CREATE VIEW vw_salesamount AS (
    SELECT
    p.ProductId
    ,p.ListPrice * s.Quantità SalesAmount
    FROM 
    sales AS s INNER JOIN 
    product AS p ON s.ProductId = p.ProductId); /* Ho creato la view per potermi ricavare il campo calcolato nella tabella sales */
     
    
    
    


    
    


